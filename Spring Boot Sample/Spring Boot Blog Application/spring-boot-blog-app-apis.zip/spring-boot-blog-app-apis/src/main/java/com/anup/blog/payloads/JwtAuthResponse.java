package com.anup.blog.payloads;

import lombok.Data;

@Data
public class JwtAuthResponse {

	private String token;
	
}

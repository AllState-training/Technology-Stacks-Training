package com.anup.blog.exceptions;

public class ApiException extends RuntimeException{

	public ApiException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ApiException(String message) {
		super(message);
		
	}

	
}
